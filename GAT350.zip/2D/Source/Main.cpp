#include "Renderer.h"
#include "Framebuffer.h"
#include "Image.h"
#include "PostProcess.h"
#include "MathUtils.h"
#include "Color.h"
#include "Model.h"
#include "Transform.h"
#include "ETime.h"
#include "Input.h"

#include <SDL.h>
#include <iostream>
#include <memory>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

int main(int argc, char* argv[]) {
    //initialize
    Time time;
    Input input;
    input.Initialize();

    Renderer renderer;
    renderer.Initialize();
    renderer.CreateWindow("2D", 800, 600);

    SetBlendMode(BlendMode::NORMAL);

    Framebuffer framebuffer(renderer, 800, 600);
    Image image;
    image.Load("bridge.jpg");

    Image imageAlpha;
    imageAlpha.Load("colors.png");
    PostProcess::Alpha(imageAlpha.m_buffer, 128);

    vertices_t vertices{ {-5, 5, 0}, {5, 5, 0}, {-5, -5, 0} };
    Model model(vertices, { 0, 255, 0, 255 });
    Transform transform{ {240, 240, 0}, glm::vec3{0, 0, 45}, glm::vec3{3} };

    bool quit = false;
    while (!quit) {
        time.Tick();
        input.Update();

        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                quit = true;
            }
            if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
                quit = true;
            }
        }

        framebuffer.Clear(color_t{ 0, 255, 0, 255 });

        for (int i = 0; i < 5; i++) {
            int x = rand() % 750;
            int y = rand() % 750;
            int x2 = rand() % 750;
            int y2 = rand() % 750;
            int x3 = rand() % 750;
            int y3 = rand() % 750;
            color_t col = { (Uint8)(rand() % 255), (Uint8)(rand() % 255), (Uint8)(rand() % 255), 255 };
            //framebuffer.DrawPoint(x, y, { 255, 255, 255, 255 });
            //framebuffer.DrawRect(100, 100, 10, 10, col);
            //framebuffer.DrawLine(0, 0, 100, 100, col);
            //framebuffer.DrawCircle(100, 200, 50, col);
            //framebuffer.DrawTriangle(200, 200, 300, 100, 400, 200, col);
            //framebuffer.DrawImage(x, y, image);
        }

        int mx, my;
        SDL_GetMouseState(&mx, &my);

        //framebuffer.DrawLinearCurve(100, 100, 200, 200, { 255, 255, 255, 255 });
        //framebuffer.DrawQuadraticCurve(100, 200, mx, my, 300, 200, 10, { 255, 255, 255, 255 });
        //framebuffer.DrawCubicCurve(300, 700, 700, 700, mx, my, 600, 400, 10, { 255, 255, 255, 255 });

        //int x, y;
        //CubicPoint(300, 700, 700, 700, mx, my, 600, 400, t, x, y);
        //framebuffer.DrawRect(x - 20, y - 20, 40, 40, { 0, 255, 0, 255 });

        //SetBlendMode(BlendMode::NORMAL);
        //framebuffer.DrawImage(100, 300, image);
        //SetBlendMode(BlendMode::MULTIPLY);
        //framebuffer.DrawImage(mx - 100, my - 100, imageAlpha);

        //PostProcess::Invert(framebuffer.m_buffer);
        //PostProcess::Monochrome(framebuffer.m_buffer);
        //PostProcess::Brightness(framebuffer.m_buffer, 20);
        //PostProcess::ColorBalance(framebuffer.m_buffer, 100, 100, -10);
        //PostProcess::Noise(framebuffer.m_buffer, 10);
        //PostProcess::Threshold(framebuffer.m_buffer, 150);
        //PostProcess::Posterize(framebuffer.m_buffer, 10);
        //PostProcess::BoxBlur(framebuffer.m_buffer, framebuffer.m_width, framebuffer.m_height);
        //PostProcess::GaussianBlur(framebuffer.m_buffer, framebuffer.m_width, framebuffer.m_height);
        //PostProcess::Sharpen(framebuffer.m_buffer, framebuffer.m_width, framebuffer.m_height);
        //PostProcess::Edge(framebuffer.m_buffer, framebuffer.m_width, framebuffer.m_height, 128);
        //PostProcess::Emboss(framebuffer.m_buffer, framebuffer.m_width, framebuffer.m_height);
        
        glm::vec3 direction{ 0 };
        if (input.GetKeyDown(SDL_SCANCODE_A)) direction.x = 1;
        if (input.GetKeyDown(SDL_SCANCODE_D)) direction.x = -1;
        if (input.GetKeyDown(SDL_SCANCODE_Q)) direction.y = -1;
        if (input.GetKeyDown(SDL_SCANCODE_E)) direction.y = 1;
        if (input.GetKeyDown(SDL_SCANCODE_W)) direction.z = 1;
        if (input.GetKeyDown(SDL_SCANCODE_S)) direction.z = -1;

        transform.position += direction * time.GetDeltaTime() * 100.0f;
        transform.rotation.z += 90 * time.GetDeltaTime();
        model.Draw(framebuffer, transform.GetMatrix());

        framebuffer.Update();
        renderer = framebuffer;

        // show screen
        SDL_RenderPresent(renderer.m_renderer);
    }

    return 0;
}